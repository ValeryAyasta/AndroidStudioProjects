
package com.example.geoquiz;

class Question(val sentence: String, val answer:Boolean) {

}
