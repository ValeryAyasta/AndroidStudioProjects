package com.example.appsemana5sesion1

class Contact (
    val name: String,
    val telephone: String
)
